This file contains outputs of the random forest models based on repeated cross-validation on the full models,
as well as for models based on top theta% predictors. The six metrics used for evaluating models are:
AUC: Area Under Curve
LIFT: Top 20% Lift
SEN: Sensitivity
SPE: Specificity
ACC: Overall accuracy
MCC: Matthews Correlation Coefficient

Each of the two files, Full_model_metrics.xlsx and Validation_metrics.xlsx contains three tabs, each corresponding to the three descriptor sets.
Rows of a tab in the first file give metrics corresponding to models built on specific train-test splits, and different values of Theta in the second file.